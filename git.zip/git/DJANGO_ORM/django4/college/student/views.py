from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.exceptions import ValidationError
from django.shortcuts import get_object_or_404
from django.shortcuts import render
from .models import Student
from .serializers import studentserializer

# Create your views here.
class StudentListCreateAPIView(APIView):
    def get(self, request):
        students = Student.objects.all()
        serializer = studentserializer(students, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = studentserializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class StudentDetailAPIView(APIView):
    def get(self, request, pk):
        students = get_object_or_404(Student, pk=pk)
        serializer = studentserializer(students)
        return Response(serializer.data)

    def put(self, request, pk):
        students = get_object_or_404(Student, pk=pk)
        serializer = studentserializer(students, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        students = get_object_or_404(Student, pk=pk)
        students.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)